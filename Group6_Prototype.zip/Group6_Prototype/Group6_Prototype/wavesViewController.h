//
//  wavesViewController.h
//  group6_prototype
//
//  Created by Su Li on 2/27/18.
//  Copyright © 2018 Su Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface wavesViewController : UIViewController
@property (strong, nonatomic) NSMutableArray *wavesArray;
@end
