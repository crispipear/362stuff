//
//  menuViewController.h
//  group6_prototype
//
//  Created by Su Li on 3/6/18.
//  Copyright © 2018 Su Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface menuViewController : UIViewController
@property (strong, nonatomic) NSMutableArray *wavesArray;

@end
