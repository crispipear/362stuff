//
//  ViewController.m
//  group6_prototype
//
//  Created by Su Li on 2/12/18.
//  Copyright © 2018 Su Li. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *circles;
@property (nonatomic) int tracker;
@end

@implementation ViewController
- (IBAction)clicked:(UIButton *)sender {
    self.tracker++;
    for(int i=0; i<self.tracker; i++){
        UIImageView *current = self.circles[i];
        current.alpha = 1.0;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tracker = 0;
    // Do any additional setup after loading the view, typically from a nib.
}


@end
