//
//  ViewController.h
//  group6_prototype
//
//  Created by Su Li on 2/12/18.
//  Copyright © 2018 Su Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

